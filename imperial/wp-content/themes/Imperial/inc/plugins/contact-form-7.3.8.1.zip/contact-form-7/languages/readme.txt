== For Translators ==

Note: this folder contains MO files and POT file only. If you are looking for PO file, you can download it from here:

http://plugins.svn.wordpress.org/contact-form-7/branches/languages/

If you have created your own translation, or have an update of an existing one, please send it to Takayuki Miyoshi <takayukister@gmail.com> so that I can bundle it into the next release of Contact Form 7.

Thank you.